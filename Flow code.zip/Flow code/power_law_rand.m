%This find is used to obtain the power-law distribution
function [x,xmin,alpha]= power_law_rand(NX,NY,EH,varH)
% NX,NY
%EH is expectation
%varH is the square deviation

% alpha the exponental of the distribution
alpha = 1+sqrt(1+EH.^2./varH);
% xmin = The min value of length
xmin = EH.*(alpha-1)./(alpha);
%x The output
alpha2 =alpha+1;
a = randn(NX,NY);
b = normcdf(abs(a));
b = 2-2*b;
x = b.^(-1/alpha2);
x = x*xmin;
end